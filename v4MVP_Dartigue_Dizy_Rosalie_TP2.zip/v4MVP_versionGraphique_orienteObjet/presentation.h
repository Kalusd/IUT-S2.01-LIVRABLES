#ifndef PRESENTATION_H
#define PRESENTATION_H

#include <QObject>
#include <QTimer>
#include "modele.h"

class LecteurDiapo; //Déclare ce mot-clé connu
class Presentation : public QObject
{
    Q_OBJECT
public:
    enum UnEtat {attente, lecture, lectureAuto};
    explicit Presentation(UnEtat e=attente, QObject *parent = nullptr);
    ~Presentation();

    //Getters et setters des attributs privés
    Modele* getModele(); //Getter de l'attribut privé _leModele
    void setModele(Modele* m); //Setter de l'attribut privé _leModele
    LecteurDiapo *getVue(); //Getter de l'attribut privé _laVue
    void setVue(LecteurDiapo* v); //Setter de l'attribut privé _laVue
    UnEtat getEtat(); //Getter de l'attribut privé _etat

    //Méthodes appelées par la vue
    void demanderAvancerDiapo(); //Permet d'avancer dans les images du diaporama, appelé quand on clique sur le bouton avancer
    void demanderReculerDiapo(); //Permet de reculer dans les images du diaporama, appelé quand on clique sur le bouton reculer
    void demanderChargerDiapo(); //Permet de changer de diaporama, appelé quand on clique sur l'action "Charger diaporama"
    void demanderEnleverDiapo(); //Permet d'enlever le diaporama actuel, appelé quand on clique sur l'action "Enlever diaporama"
    void demanderMettreLectureAutoDiapo(); //Permet d'activer la lecture automatique, appelé quand on coche la case de lecture automatique
    void demanderPauseLectureAutoDiapo(); //Permet de mettre en pause la lecture automatique, appelé quand on décoche la case de lecture automatique
    void demanderChangerVitesseDefilement(); //Permet de changer la vitesse de défilement des images en mode automatique, appelé quand on clique sur l'action "Vitesse de défilement"
    void demanderChargerDiapoID(int id, string titre, int vitesse); //Permet de charger un diapo en particulier avec son identifiant

signals:

private slots:
    void tic();

private: //Attributs privés pointant vers Vue et Modele
    Modele* _leModele;
    LecteurDiapo* _laVue;
    UnEtat _etat;
    QTimer* _timer = new QTimer(this);
    unsigned short int _tempsPasse = 0;
};

#endif // PRESENTATION_H
