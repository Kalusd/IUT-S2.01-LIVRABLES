#include "image.h"

Image::Image(string pTitre, string pCategorie, string pChemin)
{
    (*this).m_titre = pTitre;
    (*this).m_categorie = pCategorie;
    (*this).m_chemin = pChemin;
}

Image::~Image()
{
}

string Image::getCategorie()
{
    return (*this).m_categorie;
}

string Image::getTitre()
{
    return (*this).m_titre;
}

string Image::getChemin()
{
    return (*this).m_chemin;
}

void Image::afficher()
{
    cout << "image(titre:" << (*this).getTitre() << ", categorie:" << (*this).getCategorie() << ", chemin:" << (*this).getChemin() << ")" << endl;
}