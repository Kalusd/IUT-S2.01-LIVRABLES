#ifndef IMAGEDANSDIAPORAMA_H
#define IMAGEDANSDIAPORAMA_H

class ImageDansDiaporama
{
    private :
        unsigned int m_pos;   // rang de l'image dans le tableau d'images (vector<Images>)
                              // = ordre de chargement initial des images dans la table des images
        unsigned int m_rang;  // rang de l'image dans le diaporama
                              // = ordre d'affichage choisi par l'utilisateur lors de la création du diaporama
    public:
        //-- CONSTRUCTEURS --//
        ImageDansDiaporama();

        //-- DESTRUCTEURS --//
        ~ImageDansDiaporama();

        //-- Getters --//
        unsigned int getPos();
        unsigned int getRang();

        //-- Setters --//
        void setPos(unsigned int pos);
        void setRang(unsigned int rang);
};

#endif // ImageDansDiaporama_H
