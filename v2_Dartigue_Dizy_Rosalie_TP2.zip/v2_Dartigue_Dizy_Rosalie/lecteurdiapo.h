#ifndef LECTEURDIAPO_H
#define LECTEURDIAPO_H

#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui { class LecteurDiapo; }
QT_END_NAMESPACE

class LecteurDiapo : public QMainWindow
{
    Q_OBJECT

public:
    LecteurDiapo(QWidget *parent = nullptr);
    ~LecteurDiapo();

private slots:
    void avancerDiapo();
    void reculerDiapo();
    void changerDiapo();
private:
    Ui::LecteurDiapo *ui;
};
#endif // LECTEURDIAPO_H
