#ifndef LECTEURDIAPO_H
#define LECTEURDIAPO_H

#include "diaporama.h"
#include "imagedansdiaporama.h"
#include "image.h"
#include <vector>
class lecteurDiapo
{
private:
    vector <Diaporama> m_diapo;
    unsigned int m_rangDiapoCourant;

public:
    //-- CONSTRUCTEURS --//
    lecteurDiapo();

    //-- DESTRUCTEURS --//
    ~lecteurDiapo();

    //-- Méthodes --//
    int saisieVerifChoixDiapo();
    void declencherActions(char pChoixAction);
    void chargerDiapo(Diaporama& pDiaporamas);
    void ajoutDiaporamaDansTableauDiaporamas(Diaporama&);

    //-- Getters --//
    unsigned int getRangDiapoCourant();
    Diaporama getDiapoCourant();
    Diaporama getDiapoRang(unsigned int rang);
    unsigned int getTailleDiaporama();

    //-- Setters --//
    void setRangDiapoCourant(unsigned int);

    //void changerDiapo();
};

#endif // LECTEURDIAPO_H
