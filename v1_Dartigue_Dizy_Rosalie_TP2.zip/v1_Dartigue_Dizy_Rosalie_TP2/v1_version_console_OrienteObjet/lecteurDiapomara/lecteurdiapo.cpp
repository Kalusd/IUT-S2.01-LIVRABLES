#include "lecteurdiapo.h"

lecteurDiapo::lecteurDiapo(){}

lecteurDiapo::~lecteurDiapo(){}

int lecteurDiapo::saisieVerifChoixDiapo()
{
    unsigned int choixSaisi;
    unsigned int choixDiaporama; // valeur retournée

    while (true)
    {
        system("cls");  // effacer l'écran
         cout << endl << endl << "CHANGEMENT DIAPORAMA : " << endl << endl;
        for (unsigned int num = 1; num < (*this).m_diapo.size(); num++)
        {
            cout << num << ": " << (*this).m_diapo[num].getTitre();
            if (num != (*this).m_diapo.size()-1) { cout << endl; }
        }
        cout << ".......  votre choix ? "; cin >> choixSaisi;
        choixDiaporama = choixSaisi; 

        if ((choixDiaporama >= 1)&&(choixDiaporama < static_cast<unsigned int>((*this).m_diapo.size())))
        {
            break;
        }
    }
    return choixDiaporama;
}

void lecteurDiapo::declencherActions(char pChoixAction)
{
    unsigned int position;
    unsigned int choixDiaporama;

    unsigned int pImageCourante = (*this).getDiapoCourant().getRangImageCourante();

    switch (pChoixAction)
    {
        case 'A':
            (*this).getDiapoCourant().avancer(pImageCourante);
            position = (*this).getDiapoCourant().getLocalisationImageCourante().getPos();
            (*this).getDiapoCourant().afficherImageCourante(pImageCourante);
            break;
        case 'R':
            (*this).getDiapoCourant().reculer(pImageCourante);
            position = (*this).getDiapoCourant().getLocalisationImageCourante().getPos();
            (*this).getDiapoCourant().afficherImageCourante(pImageCourante);
            break;
        case 'C' :
            cout << "Choisissez un Diaporama " << endl;
            choixDiaporama = (*this).saisieVerifChoixDiapo();
            // Changer de diaporama
            (*this).m_rangDiapoCourant = choixDiaporama;
            (*this).getDiapoCourant().setRangImageCourant(0);
            break;

        default : break;
    }
}

void lecteurDiapo::chargerDiapo(Diaporama& pDiaporamas)
{
    cout << "===== chargerDiapo =====" << endl;
    Image imageACharger;
    ImageDansDiaporama imageDansDiapo;
    Diaporama diaporama;

    // Diaporama par défaut
    cout << "\tSection : Diaporama par défaut" << endl;
    (*this).getDiapoCourant().setTitre("Diaporama par defaut");
    cout << "\t----- Vérification du titre | " << (*this).getDiapoCourant().getTitre() << endl;
    (*this).getDiapoCourant().setVitesse(1);
    cout << "\t----- Vérification de la vitesse de défilement | " << (*this).getDiapoCourant().getVitesse() << endl;

    // L'unique image du diaporama par défaut
    cout << "\tSection : Préparation image du diaporama pas default" << endl << "début" << endl;
    cout << "\t----- Set loc"<< endl;
    (*this).getDiapoCourant().setLocalisationImageDansDiapo(imageDansDiapo);
    cout << "\t----- Set pos"<< endl;
    (*this).getDiapoCourant().getLocalisationImageCourante().setPos(0);
    cout << "\t----- Set rang"<< endl;
    (*this).getDiapoCourant().getLocalisationImageCourante().setRang(0);

    cout << "\t----- Vérification de imageDansDiapo | " << endl;

    cout << "Section : Préparation image du diaporama pas default" << "Fin" << endl;
    
    // ajout du diaporama dans le tableau de diaporamas
    (*this).ajoutDiaporamaDansTableauDiaporamas(diaporama);
    // vider la variable temporaire avant de la remplir avec le diaporama suivant
    (*this).getDiapoCourant().viderVecteurImageDansDiaporama();

    // Diaporama de Pantxika
    (*this).getDiapoCourant().setTitre("Diaporama Pantxika");
    (*this).getDiapoCourant().setVitesse(2);

    // Les images du diaporama de Pantxika
    (*this).getDiapoCourant().setLocalisationImageDansDiapo(imageDansDiapo);
    (*this).getDiapoCourant().getLocalisationImageCourante().setPos(4);
    (*this).getDiapoCourant().getLocalisationImageCourante().setRang(3);
    (*this).getDiapoCourant().setLocalisationImageDansDiapo(imageDansDiapo);
    (*this).getDiapoCourant().getLocalisationImageCourante().setPos(1);
    (*this).getDiapoCourant().getLocalisationImageCourante().setRang(2);
    (*this).getDiapoCourant().setLocalisationImageDansDiapo(imageDansDiapo);
    (*this).getDiapoCourant().getLocalisationImageCourante().setPos(2);
    (*this).getDiapoCourant().getLocalisationImageCourante().setRang(4);
    (*this).getDiapoCourant().setLocalisationImageDansDiapo(imageDansDiapo);
    (*this).getDiapoCourant().getLocalisationImageCourante().setPos(3);
    (*this).getDiapoCourant().getLocalisationImageCourante().setRang(1);
    // ajout du diaporama dans le tableau de diaporamas
    (*this).ajoutDiaporamaDansTableauDiaporamas(diaporama);
    // vider la variable temporaire avant de la remplir avec le diaporama suivant
    (*this).getDiapoCourant().viderVecteurImageDansDiaporama();

    // Diaporama de Thierry
    (*this).getDiapoCourant().setTitre("Diaporama Thierry");
    (*this).getDiapoCourant().setVitesse(4);

    // Les images du diaporama de Thierry
    (*this).getDiapoCourant().setLocalisationImageDansDiapo(imageDansDiapo);
    (*this).getDiapoCourant().getLocalisationImageCourante().setPos(4);
    (*this).getDiapoCourant().getLocalisationImageCourante().setRang(1);
    (*this).getDiapoCourant().setLocalisationImageDansDiapo(imageDansDiapo);
    (*this).getDiapoCourant().getLocalisationImageCourante().setPos(1);
    (*this).getDiapoCourant().getLocalisationImageCourante().setRang(2);
    (*this).getDiapoCourant().setLocalisationImageDansDiapo(imageDansDiapo);
    (*this).getDiapoCourant().getLocalisationImageCourante().setPos(2);
    (*this).getDiapoCourant().getLocalisationImageCourante().setRang(3);
    (*this).getDiapoCourant().setLocalisationImageDansDiapo(imageDansDiapo);
    (*this).getDiapoCourant().getLocalisationImageCourante().setPos(3);
    (*this).getDiapoCourant().getLocalisationImageCourante().setRang(4);
    // ajout du diaporama dans le tableau de diaporamas
    (*this).ajoutDiaporamaDansTableauDiaporamas(diaporama);
    // vider la variable temporaire avant de la remplir avec le diaporama suivant
    (*this).getDiapoCourant().viderVecteurImageDansDiaporama();

    // Diaporama de Yann
    (*this).getDiapoCourant().setTitre("Diaporama Yann");
    (*this).getDiapoCourant().setVitesse(3);

    // Les images du diaporama de Yann
    (*this).getDiapoCourant().setLocalisationImageDansDiapo(imageDansDiapo);
    (*this).getDiapoCourant().getLocalisationImageCourante().setPos(4);
    (*this).getDiapoCourant().getLocalisationImageCourante().setRang(2);
    (*this).getDiapoCourant().setLocalisationImageDansDiapo(imageDansDiapo);
    (*this).getDiapoCourant().getLocalisationImageCourante().setPos(1);
    (*this).getDiapoCourant().getLocalisationImageCourante().setRang(1);
    (*this).getDiapoCourant().setLocalisationImageDansDiapo(imageDansDiapo);
    (*this).getDiapoCourant().getLocalisationImageCourante().setPos(2);
    (*this).getDiapoCourant().getLocalisationImageCourante().setRang(4);
    (*this).getDiapoCourant().setLocalisationImageDansDiapo(imageDansDiapo);
    (*this).getDiapoCourant().getLocalisationImageCourante().setPos(3);
    (*this).getDiapoCourant().getLocalisationImageCourante().setRang(3);
    // ajout du diaporama dans le tableau de diaporamas
    (*this).ajoutDiaporamaDansTableauDiaporamas(diaporama);
    // vider la variable temporaire avant de la remplir avec le diaporama suivant
    (*this).getDiapoCourant().viderVecteurImageDansDiaporama();

    // Diaporama de Manu
    (*this).getDiapoCourant().setTitre("Diaporama Manu");
    (*this).getDiapoCourant().setVitesse(1);

    // Les images du diaporama de Manu
    (*this).getDiapoCourant().setLocalisationImageDansDiapo(imageDansDiapo);
    (*this).getDiapoCourant().getLocalisationImageCourante().setPos(4);
    (*this).getDiapoCourant().getLocalisationImageCourante().setRang(4);
    (*this).getDiapoCourant().setLocalisationImageDansDiapo(imageDansDiapo);
    (*this).getDiapoCourant().getLocalisationImageCourante().setPos(1);
    (*this).getDiapoCourant().getLocalisationImageCourante().setRang(3);
    (*this).getDiapoCourant().setLocalisationImageDansDiapo(imageDansDiapo);
    (*this).getDiapoCourant().getLocalisationImageCourante().setPos(2);
    (*this).getDiapoCourant().getLocalisationImageCourante().setRang(2);
    (*this).getDiapoCourant().setLocalisationImageDansDiapo(imageDansDiapo);
    (*this).getDiapoCourant().getLocalisationImageCourante().setPos(3);
    (*this).getDiapoCourant().getLocalisationImageCourante().setRang(1);
    // ajout du diaporama dans le tableau de diaporamas
    (*this).ajoutDiaporamaDansTableauDiaporamas(diaporama);
    // vider la variable temporaire avant de la remplir avec le diaporama suivant
    (*this).getDiapoCourant().viderVecteurImageDansDiaporama();
}


/*
void lecteurDiapo::changerDiapo()
{

}
*/

void lecteurDiapo::ajoutDiaporamaDansTableauDiaporamas(Diaporama& pDiapo) {
    (*this).m_diapo.push_back(pDiapo);
}

//-- Getters --//

unsigned int lecteurDiapo::getRangDiapoCourant() 
{
    return (*this).m_rangDiapoCourant;
}
Diaporama lecteurDiapo::getDiapoCourant() {
    return (*this).m_diapo[(*this).getRangDiapoCourant()];
}

Diaporama lecteurDiapo::getDiapoRang(unsigned int rang) {
    return (*this).m_diapo[rang];
}

unsigned int lecteurDiapo::getTailleDiaporama() {
    return static_cast<unsigned int>((*this).m_diapo.size());
}

//-- Setters --//
void lecteurDiapo::setRangDiapoCourant(unsigned int pRang) 
{
    (*this).m_rangDiapoCourant = pRang;
}