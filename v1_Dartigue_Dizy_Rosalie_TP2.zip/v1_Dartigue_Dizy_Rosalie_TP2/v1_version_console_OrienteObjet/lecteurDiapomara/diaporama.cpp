#include "diaporama.h"

Diaporama::Diaporama()
{
}

Diaporama::~Diaporama()
{
}

void Diaporama::afficherImageCourante(unsigned int pImageCourante)
{
    Image pImage = (*this).getImageRang(pImageCourante);
    cout << endl
         << endl;
    cout << "DIAPORAMA : " << (*this).m_titre << endl
         << endl;
    cout << (*this).m_localisationImages[pImageCourante].getRang() << " sur " << (*this).nbImages() << " / ";
    pImage.afficher();
}

void Diaporama::saisieVerifChoixActionSurImageCourante(char &pChoixAction)
{
    cout << endl
         << endl;
    while (true)
    {
        cout << endl;
        cout << "ACTIONS :"
             << "  A-vancer"
             << "  R-eculer"
             << "  C-hanger de diaporama "
             << "  Q-uitter .......  votre choix ? ";
        cin >> pChoixAction;
        pChoixAction = toupper(pChoixAction);

        if ((pChoixAction == 'A') || (pChoixAction == 'R') || (pChoixAction == 'C') || (pChoixAction == 'Q'))
        {
            break;
        }
    }
}

void Diaporama::chargerImage()
{
    Image imageACharger;
    imageACharger = Image("objet", "", "C:\\cartesDisney\\Disney_tapis.gif");
    (*this).m_images.push_back(imageACharger);
    imageACharger = Image("personnage", "Blanche Neige", "C:\\cartesDisney\\Disney_4.gif");
    (*this).m_images.push_back(imageACharger);
    imageACharger = Image("personnage", "Alice", "C:\\cartesDisney\\Disney_2.gif");
    (*this).m_images.push_back(imageACharger);
    imageACharger = Image("animal", "Mickey", "C:\\cartesDisney\\Disney_19.gif");
    (*this).m_images.push_back(imageACharger);
    imageACharger = Image("personnage", "Pinnochio", "C:\\cartesDisney\\Disney_29.gif");
    (*this).m_images.push_back(imageACharger);
    imageACharger = Image("objet", "chateau", "C:\\cartesDisney\\Disney_0.gif");
    (*this).m_images.push_back(imageACharger);
    imageACharger = Image("personnage", "Minnie", "C:\\cartesDisney\\Disney_14.gif");
    (*this).m_images.push_back(imageACharger);
    imageACharger = Image("animal", "Bambi", "C:\\cartesDisney\\Disney_3.gif");
    (*this).m_images.push_back(imageACharger);

    (*this).setNbImages();
}

void Diaporama::avancer(unsigned int &pPosImageCourante)
{
    if (pPosImageCourante == (*this).m_localisationImages.size() - 1)
    {
        pPosImageCourante = 0;
    }
    else
    {
        pPosImageCourante = pPosImageCourante + 1;
    }
}

void Diaporama::reculer(unsigned int &pPosImageCourante)
{
    if (pPosImageCourante == 0)
    {
        pPosImageCourante = static_cast<unsigned int>((*this).m_localisationImages.size() - 1);
    }
    else {
        pPosImageCourante = pPosImageCourante - 1;
    }
}

unsigned int Diaporama::nbImages()
{
    return static_cast<unsigned int>((*this).m_localisationImages.size());
}

void Diaporama::triCroissantRang()
{
    // par la méthode du triBulle
    unsigned int taille = static_cast<unsigned int>((*this).m_localisationImages.size());
    ImageDansDiaporama imageDansDiapo;
    for (unsigned int ici = taille-1; ici >=1 ; ici--)
    {
        // faire monter la bulle ici = déplacer l'élément de rang le plus grand en position ici
        // par échanges successifs
        for (unsigned int i = 0; i < ici; i++)
        {
            if ((*this).m_localisationImages[i].getRang() > (*this).m_localisationImages[i+1].getRang())
            {
                // echanger les 2 éléments
                imageDansDiapo = (*this).m_localisationImages[i];
                (*this).m_localisationImages[i] = (*this).m_localisationImages[i+1];
                (*this).m_localisationImages[i+1] = imageDansDiapo;
            }
        }
    }
}

void Diaporama::viderVecteurImageDansDiaporama() {
    (*this).m_localisationImages.clear();
}

//-- Getters --//
string Diaporama::getTitre() {
    return (*this).m_titre;
}   
// Retourne le titre du diaporama
unsigned int Diaporama::getVitesse() {
    return (*this).m_vitesseDefilement;
} 
// Retourne la vitesse de défilement du diaporama
unsigned int Diaporama::getRang() {
    return (*this).m_rang;
}   
// Retourne le rang du diaporama

ImageDansDiaporama Diaporama::getLocalisationImageCourante() {
    return (*this).m_localisationImages[(*this).getRangImageCourante()];
}

unsigned int Diaporama::getRangImageCourante() {
    return (*this).m_rangImageCourante;
}

Image Diaporama::getImageRang(unsigned int rang) {
    Image imageARenvoyer = (*this).m_images[rang];
    return imageARenvoyer;
}

unsigned int Diaporama::getNbImages() {
    return (*this).m_nbImages;
}

//-- Setters --//
void Diaporama::setTitre(string pTitre) {
    (*this).m_titre = pTitre;
}         
// Modifie le titre avec la valeur passée en paramètre

void Diaporama::setVitesse(unsigned int pVitesse) {
    (*this).m_vitesseDefilement = pVitesse;
} 
// Modifie la vitesse de défilement avec la valeur passée en paramètre

void Diaporama::setRang(unsigned int pRang) {
    (*this).m_rang = pRang;
}    
// Modifie le rang avec la valeur passée en paramètre

void Diaporama::setLocalisationImageDansDiapo(ImageDansDiaporama& pImage) {
    (*this).m_localisationImages.push_back(pImage);
}

void Diaporama::setNbImages() {
    (*this).m_nbImages = static_cast<unsigned int>((*this).m_images.size());
}

void Diaporama::setRangImageCourant(unsigned int pRang) {
    (*this).m_rangImageCourante = pRang;
}