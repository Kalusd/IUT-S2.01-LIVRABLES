#include "presentation.h"
#include "lecteurdiapovue.h"
#include <QDebug>
#include <QTimer>

Presentation::Presentation(UnEtat e, QObject *parent)
    : QObject{parent}, _etat(e)
{
    connect(_timer, SIGNAL(timeout()), this, SLOT(tic()));
}

Presentation::~Presentation()
{}

void Presentation::tic()
{
    _tempsPasse++;
    //qDebug() << "vitesseDefilement() = " << getModele()->getDiaporama()->getVitesseDefilement() << Qt::endl;
    qDebug() << "_tempsPasse =" << _tempsPasse << Qt::endl;
    if (_tempsPasse == getModele()->getDiaporama()->getVitesseDefilement())
    {
        getModele()->avancer();
        getVue()->majVue(_etat);
        _tempsPasse = 0;
    }
}

Modele *Presentation::getModele()
{
    return _leModele;
}

void Presentation::setModele(Modele *m)
{
    _leModele = m;
}

LecteurDiapo *Presentation::getVue()
{
    return _laVue;
}

void Presentation::setVue(LecteurDiapo *v)
{
    _laVue = v;
}

Presentation::UnEtat Presentation::getEtat()
{
    return _etat;
}

void Presentation::demanderAvancerDiapo()
{
    switch(_etat)
    {
        case attente:
            break;
        case lecture:
            demanderPauseLectureAutoDiapo();
            getModele()->avancer();
            getVue()->majVue(_etat);
            break;
        case lectureAuto:
            break;
    }
    qDebug() << "moi, presentation, j'ai recu demanderAvancerDiapo() et je fais passer l'info au modele";
}

void Presentation::demanderReculerDiapo()
{
    switch(_etat)
    {
    case attente:
        break;
    case lecture:
        demanderPauseLectureAutoDiapo();
        getModele()->reculer();
        getVue()->majVue(_etat);
        break;
    case lectureAuto:
        break;
    }
    qDebug() << "moi, presentation, j'ai recu demanderReculerDiapo() et je fais passer l'info au modele";
}

void Presentation::demanderChargerDiapo()
{
    qDebug() << "moi, presentation, j'ai recu demanderChangerDiapo() et je fais passer l'info au modele";
    getVue()->majVue(_etat);
}

void Presentation::demanderEnleverDiapo()
{
    qDebug() << "moi, presentation, j'ai recu demanderEnleverDiapo() et je fais passer l'info au modele";
}

void Presentation::demanderMettreLectureAutoDiapo()
{
    getModele()->setPosImageCourante(0);
    getVue()->majVue(_etat);
    qDebug() << "moi, presentation, j'ai recu demanderMettreLectureAutoDiapo() et je fais passer l'info au modele";
    _tempsPasse = 0;
    _timer->start(1000);
}

void Presentation::demanderPauseLectureAutoDiapo()
{
    qDebug() << "moi, presentation, j'ai recu demanderPauseLectureAutoDiapo() et je fais passer l'info au modele";
    _timer->stop();
}

void Presentation::demanderChangerVitesseDefilement()
{
    qDebug() << "moi, presentation, j'ai recu demanderChangerVitesseDefilement() et je fais passer l'info au modele";
}

void Presentation::demanderChargerDiapoID(int id, string titre, int vitesse)
{
    qDebug() << "moi, presentation, j'ai reçu demanderChargerDiapoID() et je fais passer l'info au modèle";
    switch (_etat)
    {
        case attente:
            getModele()->changerDiaporama(id, titre, vitesse);
            _etat = lecture;
            break;
        case lecture:
            getModele()->changerDiaporama(id, titre, vitesse);
            break;
        case lectureAuto:
            break; //A FAIRE PLUS TARD
    }
}



