#include "lecteurdiapo.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    LecteurDiapo w;
    w.show();
    return a.exec();
}
