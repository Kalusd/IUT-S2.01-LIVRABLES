#include "lecteurdiapovue.h"
#include "ui_lecteurdiapovue.h"
#include "presentation.h"
#include "modele.h"
#include <QDebug>
#include "diaporama.h"

LecteurDiapo::LecteurDiapo(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::LecteurDiapo)
{
    ui->setupUi(this);

    connect(ui->bSuivant, SIGNAL(clicked()), this, SLOT(demanderAvancerDiapo()));
    connect(ui->bPrecedent, SIGNAL(clicked()), this, SLOT(demanderReculerDiapo()));
    connect(ui->bLancerDiaporama, SIGNAL(clicked()), this, SLOT(demanderMettreLectureAutoDiapo()));
    connect(ui->bArreterDiaporama, SIGNAL(clicked()), this, SLOT(demanderPauseLectureAutoDiapo()));
    connect(ui->aQuitter, SIGNAL(triggered()), this, SLOT(demanderQuitter()));
    connect(ui->aChangerDiaporama, SIGNAL(triggered()), this, SLOT(demanderChargerDiapo()));
    connect(ui->aVitesseDefilement, SIGNAL(triggered()), this, SLOT(demanderChangerVitesseDefilement()));
    connect(ui->aEnleverDiaporama, SIGNAL(triggered()), this, SLOT(demanderEnleverDiapo()));
    connect(ui->aAPropos, SIGNAL(triggered()), this, SLOT(demanderAPropos()));

}

LecteurDiapo::~LecteurDiapo()
{
    delete ui;
}

Presentation *LecteurDiapo::getPresentation()
{
    return _laPresentation;
}

void LecteurDiapo::setPresentation(Presentation *p)
{
    _laPresentation = p;
}

void LecteurDiapo::majVue(Presentation::UnEtat e)
{
    switch(e)
    {
    case Presentation::UnEtat::attente:
        getPresentation()->demanderChargerDiapoID(1, "Diaporama par défaut", 2);
        ui->labelImage->setPixmap(QPixmap(QString::fromUtf8(getPresentation()->getModele()->getImageCourante()->getChemin())));
        ui->labelTitre->setText(QString::fromUtf8(getPresentation()->getModele()->getImageCourante()->getTitre()));
        ui->labelCategorie->setText(QString::fromUtf8(getPresentation()->getModele()->getImageCourante()->getCategorie()));
        ui->labelRang->setText(QString::fromUtf8(to_string(getPresentation()->getModele()->getImageCourante()->getRangDansDiaporama())));
        break;
    case Presentation::UnEtat::lecture:
        ui->labelImage->setPixmap(QPixmap(QString::fromUtf8(getPresentation()->getModele()->getImageCourante()->getChemin())));
        ui->labelTitre->setText(QString::fromUtf8(getPresentation()->getModele()->getImageCourante()->getTitre()));
        ui->labelCategorie->setText(QString::fromUtf8(getPresentation()->getModele()->getImageCourante()->getCategorie()));
        ui->labelRang->setText(QString::fromUtf8(to_string(getPresentation()->getModele()->getImageCourante()->getRangDansDiaporama())));
        break;
    case Presentation::UnEtat::lectureAuto:
        break; //A FAIRE PLUS TARD
    }
}

void LecteurDiapo::demanderAvancerDiapo()
{
    qDebug() << "Bouton Suivant cliqué ! ";
    getPresentation()->demanderAvancerDiapo();
}

void LecteurDiapo::demanderReculerDiapo()
{
    qDebug() << "Bouton Précédent cliqué ! ";
    getPresentation()->demanderReculerDiapo();
}

void LecteurDiapo::demanderChargerDiapo()
{
    qDebug() << "Action Changer diaporama cliquée ! ";
    getPresentation()->demanderChargerDiapo();
}

void LecteurDiapo::demanderEnleverDiapo()
{
    qDebug() << "Action Enlever diaporama cliquée ! ";
    getPresentation()->demanderEnleverDiapo();
}

void LecteurDiapo::demanderMettreLectureAutoDiapo()
{
    qDebug() << "Bouton \"Lancer diaporama\" cliqué ! ";
    getPresentation()->demanderMettreLectureAutoDiapo();
}

void LecteurDiapo::demanderPauseLectureAutoDiapo()
{
    qDebug() << "Bouton \"Arrêter diaporama\" cliqué ! ";
    getPresentation()->demanderPauseLectureAutoDiapo();
}

void LecteurDiapo::demanderQuitter()
{
    qDebug() << "Action Quitter cliquée ! ";
    getPresentation()->getModele()->viderLecteur();
    qDebug() << "Lecteur de diaporama vidé !";
    QCoreApplication * instanceAppli = QCoreApplication::instance(); //cf plus bas
    instanceAppli->quit();
}

void LecteurDiapo::demanderChangerVitesseDefilement()
{
    qDebug() << "Action \"Vitesse de défilement\" cliquée ! ";
    getPresentation()->demanderChangerVitesseDefilement();
}

void LecteurDiapo::demanderAPropos()
{
    qDebug() << "Action \"A propos de...\" cliquée ! ";
    QMessageBox::information(this, "A propos", "Version : V4MVP\nDate de création : 30/05/2024\nAuteurs : Yoann DARTIGUE, Lukas DIZY, Thibault ROSALIE");
}

void LecteurDiapo::demanderChargerDiapoID(int id, string titre, int vitesse)
{
    qDebug() << "ChargerDiapoID demandé !";
    getPresentation()->demanderChargerDiapoID(id, titre, vitesse);
}
