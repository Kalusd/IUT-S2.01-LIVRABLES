#include "presentation.h"
#include "lecteurdiapovue.h"
#include <QDebug>
#include <QTimer>
#include <QInputDialog>

Presentation::Presentation(UnEtat e, QObject *parent)
    : QObject{parent}, _etat(e)
{
    connect(_timer, SIGNAL(timeout()), this, SLOT(tic()));
}

Presentation::~Presentation()
{}

void Presentation::tic()
{
    _tempsPasse++;
    //qDebug() << "vitesseDefilement() = " << getModele()->getDiaporama()->getVitesseDefilement() << Qt::endl;
    qDebug() << "_tempsPasse =" << _tempsPasse << Qt::endl;
    if (_tempsPasse == getModele()->getDiaporama()->getVitesseDefilement())
    {
        getModele()->avancer();
        getVue()->majVue(_etat);
        _tempsPasse = 0;
    }
}

Modele *Presentation::getModele()
{
    return _leModele;
}

void Presentation::setModele(Modele *m)
{
    _leModele = m;
}

LecteurDiapo *Presentation::getVue()
{
    return _laVue;
}

void Presentation::setVue(LecteurDiapo *v)
{
    _laVue = v;
}

Presentation::UnEtat Presentation::getEtat()
{
    return _etat;
}

void Presentation::demanderAvancerDiapo()
{
    qDebug() << "moi, presentation, j'ai recu demanderAvancerDiapo()";
    switch(_etat)
    {
        case attente:
            break;
        case lecture:
            qDebug() << " et je fais passer l'info au modele";
            getModele()->avancer();
            getVue()->majVue(_etat);
            break;
        case lectureAuto:
            qDebug() << " et je fais passer l'info au modele";
            demanderPauseLectureAutoDiapo();
            getModele()->avancer();
            getVue()->majVue(_etat);
            break;
    }
}

void Presentation::demanderReculerDiapo()
{
    qDebug() << "moi, presentation, j'ai recu demanderReculerDiapo()";
    switch(_etat)
    {
    case attente:
        break;
    case lecture:
        qDebug() << " et je fais passer l'info au modele";
        getModele()->reculer();
        getVue()->majVue(_etat);
        break;
    case lectureAuto:
        qDebug() << " et je fais passer l'info au modele";
        demanderPauseLectureAutoDiapo();
        getModele()->reculer();
        getVue()->majVue(_etat);
        break;
    }
}

void Presentation::demanderChargerDiapo()
{ // Pas de switch car les instructions sont effectuées peu importe l'état de l'application
    qDebug() << "moi, presentation, j'ai recu demanderChangerDiapo() et je fais passer l'info au modele";
    QStringList diapos = {"Diaporama de Pantxika", "Diaporama de Thierry", "Diaporama de Yann", "Diaporama de Manu"};
    QString choix = QInputDialog::getItem(getVue(), "Changer de diaporama", "Choisissez le diaporama à afficher", diapos, 0, false); //0 indique l'item par défaut, false empêche la modification du texte
    int indiceDiapo = diapos.indexOf(choix)+1; //On ajoute 1 pour exclure le diaporama par défaut
    qDebug() << indiceDiapo << choix;
    demanderChargerDiapoID(indiceDiapo, choix.toStdString(), 2);
    getVue()->majVue(_etat);
    qDebug() << "Diaporama actuel changé à " << choix;
}

void Presentation::demanderEnleverDiapo()
{
    qDebug() << "moi, presentation, j'ai recu demanderEnleverDiapo()";
    switch(_etat)
    {
        case attente:
            break;
        case lecture:
            qDebug() << " et je fais passer l'info au modele";
            demanderChargerDiapoID(0, "Aucun diaporama chargé", 2);
            getVue()->majVue(_etat);
            qDebug() << "Diaporama enlevé";
            break;
        case lectureAuto:
            qDebug() << " et je fais passer l'info au modele";
            demanderChargerDiapoID(0, "Aucun diaporama chargé", 2);
            getVue()->majVue(_etat);
            qDebug() << "Diaporama enlevé";
            break;
    }
}

void Presentation::demanderMettreLectureAutoDiapo()
{
    qDebug() << "moi, presentation, j'ai recu demanderMettreLectureAutoDiapo()";
    switch(_etat)
    {
        case attente:
            break;
        case lecture:
            getModele()->setPosImageCourante(0);
            _etat = lectureAuto;
            getVue()->majVue(_etat);
            qDebug() << " et je fais passer l'info au modele";
            _tempsPasse = 0;
            _timer->start(1000);
            break;
        case lectureAuto:
            getModele()->setPosImageCourante(0);
            getVue()->majVue(_etat);
            qDebug() << " et je fais passer l'info au modele";
            _tempsPasse = 0;
            _timer->start(1000);
            break;
    }


}

void Presentation::demanderPauseLectureAutoDiapo()
{
    qDebug() << "moi, presentation, j'ai recu demanderPauseLectureAutoDiapo()";
    switch(_etat)
    {
        case attente:
            break;
        case lecture:
            break;
        case lectureAuto:
            qDebug() << " et je fais passer l'info au modele";
            _etat = lecture;
            _timer->stop();
            break;
    }
}

void Presentation::demanderChangerVitesseDefilement()
{ // Pas de switch car les instructions sont effectuées peu importe l'état de l'application
    int choixVitesse = QInputDialog::getInt(getVue(), "Changer la vitesse de défilement", "Choisissez la vitesse de défilement des images du diaporama", 1, 0); //1 indique la valeur par défaut, 0 indique le minimum
    getModele()->getDiaporama()->setVitesseDefilement(choixVitesse);
    qDebug() << "Vitesse de défilement changée à " << choixVitesse;
}

void Presentation::demanderChargerDiapoID(int id, string titre, int vitesse)
{
    qDebug() << "moi, presentation, j'ai reçu demanderChargerDiapoID() et je fais passer l'info au modèle";
    switch (_etat)
    {
        case attente:
            getModele()->changerDiaporama(id, titre, vitesse);
            _etat = lecture;
            break;
        case lecture:
            getModele()->changerDiaporama(id, titre, vitesse);
            break;
        case lectureAuto:
            getModele()->changerDiaporama(id, titre, vitesse);
            _etat = lecture;
            break;
    }
}



