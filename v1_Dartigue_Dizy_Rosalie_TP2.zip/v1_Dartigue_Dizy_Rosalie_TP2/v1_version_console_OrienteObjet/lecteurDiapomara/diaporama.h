#ifndef DIAPORAMA_H
#define DIAPORAMA_H

#include <iostream>
using namespace std;
#include "imagedansdiaporama.h"
#include "image.h"
#include <vector>

class Diaporama
{
private:
    string m_titre;                                  // Titre du diaporama
    unsigned int m_vitesseDefilement;                // Vitesse de défilement des images du diaporama en secondes
    vector<ImageDansDiaporama> m_localisationImages; // Images du diaporama
    vector<Image> m_images;
    unsigned int m_rang; // Rang du diaporama dans le lecteur de diaporamas
    unsigned int m_rangImageCourante;
    unsigned int m_nbImages;

public:
    //-- CONSTRUCTEURS --//
    Diaporama();

    //-- DESTRUCTEURS --//
    ~Diaporama();

    //-- METHODES --//
    void afficherImageCourante(unsigned int pImageCourante);         // Affichage à l'écran des infos de l'image courante dans son diaporama
    void saisieVerifChoixActionSurImageCourante(char &pChoixAction); // Saisie du choix d'action de l'utilisateur vis-à-vis de l'image et diaporama courants
    void chargerImage();                                             // Chargement du tableau des images avec seules les informations textuelles de quelques images
    void avancer(unsigned int &pPosImageCourante);                   // Incrémente pPosImageCourante, modulo nbImages(pDiaporama)
    void reculer(unsigned int &pPosImageCourante);                   // Décrémente pPosImageCourante, modulo nbImages(pDiaporama)
    unsigned int nbImages();                                         // Affiche la taille du diaporama pDiaporama
    void triCroissantRang();                                         // Tri du diaporama pDiaporama par ordre croissant de *rang* des ses images
    void viderVecteurImageDansDiaporama();                           // Vide le vecteur m_localisationImages

    //-- Getters --//
    string getTitre();         // Retourne le titre du diaporama
    unsigned int getVitesse(); // Retourne la vitesse de défilement du diaporama
    unsigned int getRang();    // Retourne le rang du diaporama
    ImageDansDiaporama getLocalisationImageCourante();
    unsigned int getRangImageCourante();
    Image getImageRang(unsigned int rang);
    unsigned int getNbImages();

    //-- Setters --//
    void setTitre(string);         // Modifie le titre avec la valeur passée en paramètre
    void setVitesse(unsigned int); // Modifie la vitesse de défilement avec la valeur passée en paramètre
    void setRang(unsigned int);    // Modifie le rang avec la valeur passée en paramètre
    void setLocalisationImageDansDiapo(ImageDansDiaporama &);
    void setNbImages();
    void setRangImageCourant(unsigned int);
};

#endif // DIAPORAMA_H
