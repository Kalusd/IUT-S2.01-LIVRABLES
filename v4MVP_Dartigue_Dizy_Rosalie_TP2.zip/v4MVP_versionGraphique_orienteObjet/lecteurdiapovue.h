#ifndef LECTEURDIAPOVUE_H
#define LECTEURDIAPOVUE_H

#include <QMainWindow>
#include <QMessageBox>
#include "presentation.h"
#include <QLabel>

QT_BEGIN_NAMESPACE
namespace Ui { class LecteurDiapo; }
QT_END_NAMESPACE

class Presentation; //Déclare ce mot-clé connu
class LecteurDiapo : public QMainWindow
{
    Q_OBJECT

public:
    LecteurDiapo(QWidget *parent = nullptr);
    ~LecteurDiapo();

    Presentation* getPresentation(); //Getter de l'attribut privé _laPresentation
    void setPresentation(Presentation* p); //Setter de l'attribut privé _laPresentation

    void majVue(Presentation::UnEtat e); //Ordre d'affichage envoyé par la présentation
private slots:
    void demanderAvancerDiapo(); //Permet d'avancer dans les images du diaporama, appelé quand on clique sur le bouton "Suivant"
    void demanderReculerDiapo(); //Permet de reculer dans les images du diaporama, appelé quand on clique sur le bouton "Précédent"
    void demanderChargerDiapo(); //Permet de changer de diaporama, appelé quand on clique sur l'action "Charger diaporama"
    void demanderEnleverDiapo(); //Permet d'enlever le diaporama actuel, appelé quand on clique sur l'action "Enlever diaporama"
    void demanderMettreLectureAutoDiapo(); //Permet d'activer la lecture automatique, appelé quand on clique sur le bouton "Lancer diaporama"
    void demanderPauseLectureAutoDiapo(); //Permet de désactiver la lecture automatique, appelé quand on clique sur le bouton "Arrêter diaporama"
    void demanderQuitter(); //Permet de quitter le lecteur de diaporama après avoir enlevé le diaporama actuel, appelé quand on clique sur l'action "Quitter"
    void demanderChangerVitesseDefilement(); //Permet de changer la vitesse de défilement des images en mode automatique, appelé quand on clique sur l'action "Vitesse de défilement"
    void demanderAPropos(); //Permet d'afficher la fenêtre a propos du lecteur de diaporama, appelé quand on clique sur l'action "A propos de..."
    void demanderChargerDiapoID(int id, string titre, int vitesse); //Permet de charger un diapo en particulier avec son identifiant

private:
    Ui::LecteurDiapo *ui;
    Presentation* _laPresentation;


};
#endif // LECTEURDIAPOVUE_H
