#include "lecteurdiapovue.h"
#include "modele.h"
#include "presentation.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    LecteurDiapo w;
    Modele *m = new Modele();
    Presentation* p = new Presentation();

    //Lier la vue et la présentation
    p->setVue(&w);
    w.setPresentation(p);

    //Lier la présentation et le modèle
    p->setModele(m);
    w.majVue(p->getEtat());

    w.show();
    return a.exec();
}
