#ifndef IMAGE_H
#define IMAGE_H

#include <iostream>
using namespace std;

class Image
{
    private :
        string m_titre;     // Intitulé de l'Image
        string m_categorie; // Catégorie de l'Image (pesronne, animal, objet)
        string m_chemin;    // Chemin absolu vers l'Image dans son dossier

    public:
        Image(string pTitre="", string pCategorie="", string pChemin = "");
        ~Image();

        string getCategorie();
        string getTitre();
        string getChemin();

        void afficher();
};

#endif // IMAGE_H
