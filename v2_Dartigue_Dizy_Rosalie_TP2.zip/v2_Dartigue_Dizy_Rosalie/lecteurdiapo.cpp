#include "lecteurdiapo.h"
#include "ui_lecteurdiapo.h"
#include <QDebug>

LecteurDiapo::LecteurDiapo(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::LecteurDiapo)
{
    ui->setupUi(this);
    connect(ui->bAvancer, SIGNAL(clicked()), this, SLOT(avancerDiapo()));
    connect(ui->bReculer, SIGNAL(clicked()), this, SLOT(reculerDiapo()));
    connect(ui->actionChangerDiapo, SIGNAL(triggered()), this, SLOT(changerDiapo()));

    ui->imageDiapo->setPixmap(QPixmap(QString::fromUtf8(":/images/images/ampouleAllumee2.PNG")));

}

LecteurDiapo::~LecteurDiapo()
{
    delete ui;
}

void LecteurDiapo::avancerDiapo()
{
    qDebug() << "Bouton Avancer cliqué ! " << Qt::endl;
}

void LecteurDiapo::reculerDiapo()
{
    qDebug() << "Bouton Reculer cliqué ! " << Qt::endl;
}

void LecteurDiapo::changerDiapo()
{
    qDebug() << "Action ChangerDiapo cliquée ! " << Qt::endl;
}


