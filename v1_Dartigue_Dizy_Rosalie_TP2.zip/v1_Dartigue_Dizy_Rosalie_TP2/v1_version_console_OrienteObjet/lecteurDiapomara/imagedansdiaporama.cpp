#include "imagedansdiaporama.h"

//-- CONSTRUCTEURS --//
ImageDansDiaporama::ImageDansDiaporama(){}

//-- DESTRUCTEURS --//
ImageDansDiaporama::~ImageDansDiaporama(){}

//-- Getters --//
unsigned int ImageDansDiaporama::getPos(){
    return (*this).m_pos;
}

unsigned int ImageDansDiaporama::getRang(){
    return (*this).m_rang;
}

//-- Setters --//
void ImageDansDiaporama::setPos(unsigned int pos) {
    (*this).m_pos = pos;
}

void ImageDansDiaporama::setRang(unsigned int rang) {
    (*this).m_rang = rang;
}